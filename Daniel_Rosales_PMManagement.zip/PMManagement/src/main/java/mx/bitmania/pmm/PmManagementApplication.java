package mx.bitmania.pmm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PmManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(PmManagementApplication.class, args);
	}

}
